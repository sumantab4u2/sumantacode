package com.challenge.orderservice.service;

import com.challenge.orderservice.repository.OrderRepository;
import com.challenge.orderservice.entity.Order;
import com.challenge.orderservice.entity.OrderItem;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }
    
    OrderItem orderItem=new OrderItem();
    Order order=new Order();

    public double calculateTotalRevenue() {
    	
    	int item=orderItem.getQuantity();
    	double order=orderItem.getPrice();
        return item*order;
       
    }

    public Map<String, List<Order>> groupOrdersByCustomer() {
        return Map.of();
    }

    public List<String> getTopSpentCustomers(int n) {
        order.getCustomerId();
    	order.getItems();
        return List.of();
    }
}
