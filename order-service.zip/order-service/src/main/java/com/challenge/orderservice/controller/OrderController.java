package com.challenge.orderservice.controller;

import com.challenge.orderservice.entity.Order;
import com.challenge.orderservice.repository.OrderRepository;
import com.challenge.orderservice.service.OrderService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

	@Autowired
    private final OrderService orderService;
	

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }
    
    @GetMapping("/totalRevenue")
    public double calculateTotalRevenue()
    {
    	return orderService.calculateTotalRevenue();
		
    }
    
    
    @GetMapping("/orderByCustomer")
    public Map<String, List<Order>> groupOrdersByCustomer()
    {
    	return orderService.groupOrdersByCustomer();
		
    }
    
    @GetMapping("/id")
    public List<String> getTopSpentCustomers(@PathVariable int id)
    {
    	return orderService.getTopSpentCustomers(id);
		
    }
    

    
   
}
